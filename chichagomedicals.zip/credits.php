<?php
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Credits</title>
</head>
<body>
<h3>Default profile pic image</h3>
<a href="https://www.freepik.com/vectors/fashion">Fashion vector created by studiogstock - www.freepik.com</a>
</body>
</html>
