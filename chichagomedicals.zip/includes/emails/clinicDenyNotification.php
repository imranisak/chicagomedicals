<p>
	You clinic has not been approved on Chicago Medicals. Here's why:
</p>
<?php 
echo $reason
?>